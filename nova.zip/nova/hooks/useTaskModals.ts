"use client";

import { useState } from "react";
import { Task } from "@/types/task";

export function useTaskModals() {
  const [composerOpen, setComposerOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  return {
    composerOpen,
    openComposer: () => setComposerOpen(true),
    closeComposer: () => setComposerOpen(false),
    selectedTask,
    openDetails: (task: Task) => setSelectedTask(task),
    closeDetails: () => setSelectedTask(null),
  };
}
