"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import { FilterKind, Project, SortKind, Task, ViewState } from "@/types/task";
import { storage, STORAGE_KEYS } from "@/lib/storage";
import { buildSeedTasks, seedProjects } from "@/data/seed";
import { genId } from "@/lib/tasks";

type NewTaskInput = {
  title: string;
  description?: string;
  priority: Task["priority"];
  project?: string;
  tags: string[];
  dueDate?: string;
  dueTime?: string;
};

type TaskContextValue = {
  tasks: Task[];
  projects: Project[];
  view: ViewState;
  setFilter: (f: FilterKind) => void;
  setSort: (s: SortKind) => void;
  setQuery: (q: string) => void;
  addTask: (input: NewTaskInput) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  toggleComplete: (id: string) => void;
  deleteTask: (id: string) => void;
  reorderTasks: (orderedIds: string[]) => void;
  hydrated: boolean;
};

const TaskContext = createContext<TaskContextValue | null>(null);

const defaultView: ViewState = { filter: "all", sort: "dueDate", query: "" };

export function TaskProvider({ children }: { children: React.ReactNode }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [projects] = useState<Project[]>(seedProjects);
  const [view, setView] = useState<ViewState>(defaultView);
  const [hydrated, setHydrated] = useState(false);

  // Hydrate from localStorage (or seed) on mount.
  useEffect(() => {
    const seeded = storage.get<boolean>(STORAGE_KEYS.seeded, false);
    if (!seeded) {
      const seedTasks = buildSeedTasks();
      storage.set(STORAGE_KEYS.tasks, seedTasks);
      storage.set(STORAGE_KEYS.seeded, true);
      setTasks(seedTasks);
    } else {
      setTasks(storage.get<Task[]>(STORAGE_KEYS.tasks, []));
    }
    setView(storage.get<ViewState>(STORAGE_KEYS.view, defaultView));
    setHydrated(true);
  }, []);

  // Persist tasks whenever they change (after initial hydration).
  useEffect(() => {
    if (!hydrated) return;
    storage.set(STORAGE_KEYS.tasks, tasks);
  }, [tasks, hydrated]);

  useEffect(() => {
    if (!hydrated) return;
    storage.set(STORAGE_KEYS.view, view);
  }, [view, hydrated]);

  const setFilter = useCallback((f: FilterKind) => {
    setView((v) => ({ ...v, filter: f }));
  }, []);
  const setSort = useCallback((s: SortKind) => {
    setView((v) => ({ ...v, sort: s }));
  }, []);
  const setQuery = useCallback((q: string) => {
    setView((v) => ({ ...v, query: q }));
  }, []);

  const addTask = useCallback((input: NewTaskInput) => {
    setTasks((prev) => {
      const maxOrder = prev.reduce((m, t) => Math.max(m, t.order), -1);
      const task: Task = {
        id: genId(),
        title: input.title,
        description: input.description ?? "",
        completed: false,
        priority: input.priority,
        project: input.project,
        tags: input.tags,
        dueDate: input.dueDate,
        dueTime: input.dueTime,
        createdAt: new Date().toISOString(),
        order: maxOrder + 1,
      };
      return [task, ...prev];
    });
  }, []);

  const updateTask = useCallback((id: string, patch: Partial<Task>) => {
    setTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, ...patch } : t))
    );
  }, []);

  const toggleComplete = useCallback((id: string) => {
    setTasks((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              completed: !t.completed,
              completedAt: !t.completed ? new Date().toISOString() : undefined,
            }
          : t
      )
    );
  }, []);

  const deleteTask = useCallback((id: string) => {
    setTasks((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const reorderTasks = useCallback((orderedIds: string[]) => {
    setTasks((prev) => {
      const map = new Map(prev.map((t) => [t.id, t]));
      const reordered = orderedIds
        .map((id) => map.get(id))
        .filter((t): t is Task => Boolean(t));
      const untouched = prev.filter((t) => !orderedIds.includes(t.id));
      return [...reordered, ...untouched].map((t, i) => ({ ...t, order: i }));
    });
  }, []);

  const value = useMemo(
    () => ({
      tasks,
      projects,
      view,
      setFilter,
      setSort,
      setQuery,
      addTask,
      updateTask,
      toggleComplete,
      deleteTask,
      reorderTasks,
      hydrated,
    }),
    [
      tasks,
      projects,
      view,
      setFilter,
      setSort,
      setQuery,
      addTask,
      updateTask,
      toggleComplete,
      deleteTask,
      reorderTasks,
      hydrated,
    ]
  );

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
}

export function useTasks() {
  const ctx = useContext(TaskContext);
  if (!ctx) throw new Error("useTasks must be used within TaskProvider");
  return ctx;
}
