"use client";

import { useMemo } from "react";
import { Inbox as InboxIcon } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { useTaskModals } from "@/hooks/useTaskModals";
import { applyFilter, applySort, matchesQuery } from "@/lib/tasks";
import { FilterBar } from "@/components/FilterBar";
import { TaskList } from "@/components/TaskList";
import { NewTaskButton } from "@/components/NewTaskButton";
import { TaskComposer } from "@/components/TaskComposer";
import { TaskDetails } from "@/components/TaskDetails";
import { EmptyState } from "@/components/EmptyState";

export default function InboxPage() {
  const { tasks, view, setFilter, setSort, hydrated } = useTasks();
  const modals = useTaskModals();

  const inboxTasks = useMemo(() => tasks.filter((t) => !t.project), [tasks]);

  const visible = useMemo(() => {
    let list = applyFilter(inboxTasks, view.filter);
    list = list.filter((t) => matchesQuery(t, view.query));
    return applySort(list, view.sort);
  }, [inboxTasks, view]);

  if (!hydrated) return null;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
            Unassigned
          </div>
          <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
            Inbox
          </h1>
        </div>
        <NewTaskButton onClick={modals.openComposer} />
      </div>

      <FilterBar
        filter={view.filter}
        sort={view.sort}
        onFilterChange={setFilter}
        onSortChange={setSort}
      />

      {visible.length === 0 ? (
        <EmptyState
          icon={InboxIcon}
          title="INBOX CLEAR"
          subtitle="Everything has been routed."
        />
      ) : (
        <TaskList tasks={visible} onOpen={modals.openDetails} reorderable />
      )}

      <TaskComposer open={modals.composerOpen} onClose={modals.closeComposer} />
      <TaskDetails task={modals.selectedTask} onClose={modals.closeDetails} />
    </div>
  );
}
