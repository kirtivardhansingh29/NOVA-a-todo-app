"use client";

import { useMemo } from "react";
import { notFound } from "next/navigation";
import { useTasks } from "@/hooks/useTasks";
import { useTaskModals } from "@/hooks/useTaskModals";
import { applyFilter, applySort, matchesQuery } from "@/lib/tasks";
import { FilterBar } from "@/components/FilterBar";
import { TaskList } from "@/components/TaskList";
import { ProgressIndicator } from "@/components/ProgressIndicator";
import { NewTaskButton } from "@/components/NewTaskButton";
import { TaskComposer } from "@/components/TaskComposer";
import { TaskDetails } from "@/components/TaskDetails";
import { EmptyState } from "@/components/EmptyState";
import { Folder } from "lucide-react";

export default function ProjectDetailPage({
  params,
}: {
  params: { slug: string };
}) {
  const { tasks, projects, view, setFilter, setSort, hydrated } = useTasks();
  const modals = useTaskModals();

  const project = projects.find((p) => p.slug === params.slug);

  const projectTasks = useMemo(
    () => (project ? tasks.filter((t) => t.project === project.id) : []),
    [tasks, project]
  );

  const visible = useMemo(() => {
    let list = applyFilter(projectTasks, view.filter);
    list = list.filter((t) => matchesQuery(t, view.query));
    return applySort(list, view.sort);
  }, [projectTasks, view]);

  if (!hydrated) return null;
  if (!project) notFound();

  const completedCount = projectTasks.filter((t) => t.completed).length;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
            Project
          </div>
          <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
            {project.name}
          </h1>
        </div>
        <NewTaskButton onClick={modals.openComposer} />
      </div>

      <ProgressIndicator completed={completedCount} total={projectTasks.length} />

      <FilterBar
        filter={view.filter}
        sort={view.sort}
        onFilterChange={setFilter}
        onSortChange={setSort}
      />

      {visible.length === 0 ? (
        <EmptyState
          icon={Folder}
          title="NO TASKS HERE"
          subtitle={`Add the first task to ${project.name}.`}
        />
      ) : (
        <TaskList tasks={visible} onOpen={modals.openDetails} reorderable />
      )}

      <TaskComposer
        open={modals.composerOpen}
        onClose={modals.closeComposer}
        defaultProject={project.id}
      />
      <TaskDetails task={modals.selectedTask} onClose={modals.closeDetails} />
    </div>
  );
}
