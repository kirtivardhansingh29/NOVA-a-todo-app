import { ProjectList } from "@/components/ProjectList";

export default function ProjectsPage() {
  return (
    <div className="flex flex-col gap-6">
      <div>
        <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
          Workspaces
        </div>
        <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
          Projects
        </h1>
      </div>
      <ProjectList />
    </div>
  );
}
