"use client";

import { useMemo } from "react";
import { CheckCircle2 } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { useTaskModals } from "@/hooks/useTaskModals";
import { matchesQuery } from "@/lib/tasks";
import { TaskList } from "@/components/TaskList";
import { TaskDetails } from "@/components/TaskDetails";
import { EmptyState } from "@/components/EmptyState";

export default function CompletedPage() {
  const { tasks, view, hydrated } = useTasks();
  const modals = useTaskModals();

  const completed = useMemo(() => {
    return tasks
      .filter((t) => t.completed)
      .filter((t) => matchesQuery(t, view.query))
      .sort((a, b) => (b.completedAt ?? "").localeCompare(a.completedAt ?? ""));
  }, [tasks, view.query]);

  if (!hydrated) return null;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
          Archive
        </div>
        <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
          Completed
        </h1>
      </div>

      {completed.length === 0 ? (
        <EmptyState
          icon={CheckCircle2}
          title="NO COMPLETED TASKS"
          subtitle="Finished work will collect here."
        />
      ) : (
        <TaskList tasks={completed} onOpen={modals.openDetails} />
      )}

      <TaskDetails task={modals.selectedTask} onClose={modals.closeDetails} />
    </div>
  );
}
