"use client";

import { useMemo } from "react";
import { CalendarClock } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { useTaskModals } from "@/hooks/useTaskModals";
import { groupUpcoming, matchesQuery } from "@/lib/tasks";
import { TaskList } from "@/components/TaskList";
import { NewTaskButton } from "@/components/NewTaskButton";
import { TaskComposer } from "@/components/TaskComposer";
import { TaskDetails } from "@/components/TaskDetails";
import { EmptyState } from "@/components/EmptyState";

export default function UpcomingPage() {
  const { tasks, view, hydrated } = useTasks();
  const modals = useTaskModals();

  const groups = useMemo(() => {
    const filtered = tasks.filter((t) => matchesQuery(t, view.query));
    return groupUpcoming(filtered);
  }, [tasks, view.query]);

  if (!hydrated) return null;

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <div>
          <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
            Schedule
          </div>
          <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
            Upcoming
          </h1>
        </div>
        <NewTaskButton onClick={modals.openComposer} />
      </div>

      {groups.length === 0 ? (
        <EmptyState
          icon={CalendarClock}
          title="NOTHING AHEAD"
          subtitle="No tasks are scheduled beyond today."
        />
      ) : (
        <div className="flex flex-col gap-7">
          {groups.map((g) => (
            <div key={g.label} className="relative">
              <div className="mb-2 flex items-center gap-3">
                <span className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink-500">
                  {g.label}
                </span>
                <span className="h-px flex-1 bg-graphite-600" />
                <span className="font-mono text-[10px] text-ink-700">
                  {g.tasks.length}
                </span>
              </div>
              <TaskList tasks={g.tasks} onOpen={modals.openDetails} />
            </div>
          ))}
        </div>
      )}

      <TaskComposer open={modals.composerOpen} onClose={modals.closeComposer} />
      <TaskDetails task={modals.selectedTask} onClose={modals.closeDetails} />
    </div>
  );
}
