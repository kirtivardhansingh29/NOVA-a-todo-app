"use client";

import { useMemo } from "react";
import { useTasks } from "@/hooks/useTasks";
import { useTaskModals } from "@/hooks/useTaskModals";
import { applyFilter, applySort, formatFullDate, isOverdue, isToday, matchesQuery } from "@/lib/tasks";
import { FilterBar } from "@/components/FilterBar";
import { TaskList } from "@/components/TaskList";
import { ProgressIndicator } from "@/components/ProgressIndicator";
import { NewTaskButton } from "@/components/NewTaskButton";
import { TaskComposer } from "@/components/TaskComposer";
import { TaskDetails } from "@/components/TaskDetails";
import { EmptyState } from "@/components/EmptyState";
import { Sparkles } from "lucide-react";

export default function TodayPage() {
  const { tasks, view, setFilter, setSort, hydrated } = useTasks();
  const modals = useTaskModals();

  const todaysTasks = useMemo(
    () => tasks.filter((t) => isToday(t) || isOverdue(t)),
    [tasks]
  );

  const completedToday = todaysTasks.filter((t) => t.completed).length;

  const visible = useMemo(() => {
    let list = applyFilter(todaysTasks, view.filter);
    list = list.filter((t) => matchesQuery(t, view.query));
    return applySort(list, view.sort);
  }, [todaysTasks, view]);

  const dateLabel = formatFullDate(new Date());

  if (!hydrated) return null;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
          {dateLabel}
        </div>
        <div className="mt-1 flex items-center justify-between">
          <h1 className="font-display text-2xl font-medium text-ink-100">
            Today&apos;s Operations
          </h1>
          <NewTaskButton onClick={modals.openComposer} />
        </div>
      </div>

      <ProgressIndicator completed={completedToday} total={todaysTasks.length} />

      <FilterBar
        filter={view.filter}
        sort={view.sort}
        onFilterChange={setFilter}
        onSortChange={setSort}
      />

      {visible.length === 0 ? (
        <EmptyState
          icon={Sparkles}
          title="NOTHING SCHEDULED"
          subtitle="Add a task to start today's run."
        />
      ) : (
        <TaskList tasks={visible} onOpen={modals.openDetails} reorderable />
      )}

      <TaskComposer
        open={modals.composerOpen}
        onClose={modals.closeComposer}
      />
      <TaskDetails task={modals.selectedTask} onClose={modals.closeDetails} />
    </div>
  );
}
