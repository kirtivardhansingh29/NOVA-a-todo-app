"use client";

import { useState } from "react";
import { useTasks } from "@/hooks/useTasks";
import { storage, STORAGE_KEYS } from "@/lib/storage";

export default function SettingsPage() {
  const { tasks, hydrated } = useTasks();
  const [confirming, setConfirming] = useState(false);

  function handleReset() {
    storage.remove(STORAGE_KEYS.tasks);
    storage.remove(STORAGE_KEYS.seeded);
    storage.remove(STORAGE_KEYS.view);
    window.location.href = "/today";
  }

  if (!hydrated) return null;

  return (
    <div className="flex flex-col gap-8">
      <div>
        <div className="font-mono text-[11px] uppercase tracking-[0.14em] text-ink-700">
          Configuration
        </div>
        <h1 className="mt-1 font-display text-2xl font-medium text-ink-100">
          Settings
        </h1>
      </div>

      <section className="rounded-md border border-graphite-600">
        <div className="border-b border-graphite-600 px-4 py-3">
          <div className="text-sm text-ink-100">Storage</div>
          <div className="mt-0.5 text-xs text-ink-700">
            NØVA persists everything to your browser&apos;s local storage. No
            account, no server, no sync.
          </div>
        </div>
        <div className="flex items-center justify-between px-4 py-3">
          <div className="font-mono text-[11px] uppercase tracking-wide text-ink-500">
            {tasks.length} tasks stored
          </div>
          {!confirming ? (
            <button
              onClick={() => setConfirming(true)}
              className="rounded-md border border-graphite-600 px-3 py-1.5 text-xs text-priority-urgent hover:border-priority-urgent/50"
            >
              Reset local data
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-xs text-ink-500">
                This clears every task. Sure?
              </span>
              <button
                onClick={handleReset}
                className="rounded bg-priority-urgent/20 px-2 py-1 text-xs text-priority-urgent hover:bg-priority-urgent/30"
              >
                Reset
              </button>
              <button
                onClick={() => setConfirming(false)}
                className="text-xs text-ink-500 hover:text-ink-100"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="rounded-md border border-graphite-600">
        <div className="border-b border-graphite-600 px-4 py-3">
          <div className="text-sm text-ink-100">About</div>
        </div>
        <div className="flex flex-col gap-2 px-4 py-3 text-xs text-ink-500">
          <div className="flex justify-between">
            <span>Build</span>
            <span className="font-mono text-ink-700">nova · frontend skeleton</span>
          </div>
          <div className="flex justify-between">
            <span>Stack</span>
            <span className="font-mono text-ink-700">
              next · react · tailwind · framer-motion
            </span>
          </div>
          <div className="flex justify-between">
            <span>Persistence</span>
            <span className="font-mono text-ink-700">localStorage</span>
          </div>
        </div>
      </section>
    </div>
  );
}
