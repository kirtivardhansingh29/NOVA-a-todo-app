import { Project, Task } from "@/types/task";

export const seedProjects: Project[] = [
  { id: "personal", name: "Personal", slug: "personal" },
  { id: "college", name: "College", slug: "college" },
  { id: "projects", name: "Projects", slug: "projects" },
  { id: "learning", name: "Learning", slug: "learning" },
];

function daysFromNow(n: number): string {
  const d = new Date();
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

const today = daysFromNow(0);

export function buildSeedTasks(): Task[] {
  const now = new Date().toISOString();
  const rows: Array<Partial<Task> & { title: string }> = [
    {
      title: "Finish DAA assignment",
      priority: "high",
      project: "college",
      tags: ["assignment"],
      dueDate: today,
      dueTime: "18:00",
    },
    {
      title: "Review project architecture",
      priority: "medium",
      project: "projects",
      tags: ["architecture", "review"],
      dueDate: today,
    },
    {
      title: "Prepare event proposal",
      priority: "urgent",
      project: "college",
      tags: ["proposal"],
      dueDate: daysFromNow(1),
    },
    {
      title: "Push latest changes to GitHub",
      priority: "medium",
      project: "projects",
      tags: ["git"],
      dueDate: today,
    },
    {
      title: "Study operating systems",
      priority: "medium",
      project: "learning",
      tags: ["os", "exam-prep"],
      dueDate: daysFromNow(2),
    },
    {
      title: "Design project landing page",
      priority: "low",
      project: "projects",
      tags: ["design"],
      dueDate: daysFromNow(4),
    },
    {
      title: "Review hackathon requirements",
      priority: "high",
      project: "college",
      tags: ["hackathon"],
      dueDate: daysFromNow(1),
    },
    {
      title: "Practice LeetCode problems",
      priority: "low",
      project: "learning",
      tags: ["dsa", "practice"],
      dueDate: daysFromNow(0),
    },
    {
      title: "Sort holiday photos",
      priority: "low",
      project: "personal",
      tags: [],
      dueDate: daysFromNow(6),
    },
    {
      title: "Call the internet provider about billing",
      priority: "medium",
      tags: ["calls"],
      dueDate: daysFromNow(1),
    },
    {
      title: "Draft weekly chapter update",
      priority: "medium",
      project: "college",
      tags: ["writing"],
      completed: true,
    },
  ];

  return rows.map((r, i) => ({
    id: `seed-${i}`,
    title: r.title,
    description: r.description ?? "",
    completed: r.completed ?? false,
    priority: r.priority ?? "medium",
    project: r.project,
    tags: r.tags ?? [],
    dueDate: r.dueDate,
    dueTime: r.dueTime,
    createdAt: now,
    completedAt: r.completed ? now : undefined,
    order: i,
  }));
}
