export type Priority = "low" | "medium" | "high" | "urgent";

export type Task = {
  id: string;
  title: string;
  description?: string;
  completed: boolean;
  priority: Priority;
  project?: string; // project id, undefined = inbox
  tags: string[];
  dueDate?: string; // ISO date string, e.g. 2026-09-27
  dueTime?: string; // e.g. "14:30"
  createdAt: string;
  completedAt?: string;
  order: number;
};

export type Project = {
  id: string;
  name: string;
  slug: string;
};

export type FilterKind =
  | "all"
  | "active"
  | "completed"
  | "high"
  | "today"
  | "overdue";

export type SortKind = "dueDate" | "priority" | "newest" | "oldest";

export type ViewState = {
  filter: FilterKind;
  sort: SortKind;
  query: string;
};
