export function StatusIndicator({
  label = "SYSTEM ONLINE",
}: {
  label?: string;
}) {
  return (
    <div className="flex items-center gap-2 text-micro font-mono uppercase tracking-wide text-ink-500">
      <span className="relative flex h-1.5 w-1.5">
        <span className="absolute inline-flex h-full w-full rounded-full bg-signal animate-pulse-dot" />
      </span>
      <span>{label}</span>
    </div>
  );
}
