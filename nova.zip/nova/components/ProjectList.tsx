"use client";

import Link from "next/link";
import { ChevronRight } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";

export function ProjectList() {
  const { projects, tasks } = useTasks();

  return (
    <div className="flex flex-col divide-y divide-graphite-600/70 border-t border-graphite-600">
      {projects.map((p) => {
        const projectTasks = tasks.filter((t) => t.project === p.id);
        const completed = projectTasks.filter((t) => t.completed).length;
        const total = projectTasks.length;
        const pct = total === 0 ? 0 : Math.round((completed / total) * 100);

        return (
          <Link
            key={p.id}
            href={`/projects/${p.slug}`}
            className="group flex items-center justify-between gap-4 py-3.5 transition-colors hover:bg-graphite-800/40"
          >
            <div className="flex min-w-0 items-center gap-3">
              <span className="h-1.5 w-1.5 shrink-0 rounded-full border border-ink-700" />
              <span className="truncate text-sm text-ink-100">{p.name}</span>
            </div>

            <div className="flex shrink-0 items-center gap-4">
              <span className="font-mono text-[11px] text-ink-700">
                {completed}/{total}
              </span>
              <div className="h-[3px] w-20 rounded-full bg-graphite-600">
                <div
                  className="h-full rounded-full bg-signal"
                  style={{ width: `${pct}%` }}
                />
              </div>
              <ChevronRight
                size={14}
                className="text-ink-700 transition-transform group-hover:translate-x-0.5"
              />
            </div>
          </Link>
        );
      })}
    </div>
  );
}
