"use client";

import { Menu, Search } from "lucide-react";
import { StatusIndicator } from "@/components/StatusIndicator";

export function TopBar({
  onOpenPalette,
  onOpenMobileNav,
}: {
  onOpenPalette: () => void;
  onOpenMobileNav: () => void;
}) {
  const isMac =
    typeof window !== "undefined" && /Mac|iPod|iPhone|iPad/.test(navigator.platform);

  return (
    <div className="flex h-14 shrink-0 items-center justify-between border-b border-graphite-600 bg-graphite-900/80 px-4 backdrop-blur md:px-6">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenMobileNav}
          className="rounded p-1.5 text-ink-500 hover:text-ink-100 md:hidden"
          aria-label="Open navigation"
        >
          <Menu size={18} />
        </button>
        <button
          onClick={onOpenPalette}
          className="flex w-56 items-center gap-2 rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-1.5 text-left text-ink-700 transition-colors hover:border-graphite-500 hover:text-ink-500 sm:w-72"
        >
          <Search size={14} />
          <span className="flex-1 text-sm">Search…</span>
          <kbd className="hidden font-mono text-[10px] sm:inline">
            {isMac ? "⌘" : "Ctrl"} K
          </kbd>
        </button>
      </div>
      <StatusIndicator />
    </div>
  );
}
