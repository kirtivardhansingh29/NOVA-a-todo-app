"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { GripVertical, MoreHorizontal, Trash2, Pencil } from "lucide-react";
import { Task } from "@/types/task";
import { formatDueLabel, isOverdue } from "@/lib/tasks";
import { PriorityDot } from "@/components/PriorityDot";
import { cn } from "@/lib/cn";

export function TaskRow({
  task,
  projectName,
  onToggle,
  onOpen,
  onDelete,
  draggable = false,
  onDragStart,
  onDragOver,
  onDrop,
}: {
  task: Task;
  projectName?: string;
  onToggle: () => void;
  onOpen: () => void;
  onDelete: () => void;
  draggable?: boolean;
  onDragStart?: () => void;
  onDragOver?: (e: React.DragEvent) => void;
  onDrop?: () => void;
}) {
  const [menuOpen, setMenuOpen] = useState(false);
  const [confirming, setConfirming] = useState(false);
  const overdue = isOverdue(task);
  const dueLabel = task.completed
    ? task.completedAt
      ? `DONE ${new Date(task.completedAt).toLocaleDateString("en-US", {
          month: "short",
          day: "numeric",
        }).toUpperCase()}`
      : ""
    : formatDueLabel(task.dueDate);

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 4 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, height: 0, marginTop: 0, marginBottom: 0 }}
      transition={{ duration: 0.18, ease: "easeOut" }}
      draggable={draggable}
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
      className={cn(
        "group relative flex items-center gap-3 border-b border-graphite-600/70 py-2.5 pl-1 pr-2 transition-colors hover:bg-graphite-800/50",
        task.completed && "opacity-50"
      )}
    >
      <span className="cursor-grab text-graphite-600 opacity-0 transition-opacity group-hover:opacity-100">
        <GripVertical size={14} />
      </span>

      <button
        onClick={onToggle}
        aria-label={task.completed ? "Mark incomplete" : "Mark complete"}
        className={cn(
          "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border transition-colors",
          task.completed
            ? "border-signal bg-signal/20"
            : "border-graphite-500 hover:border-signal"
        )}
      >
        {task.completed && (
          <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
            <path
              d="M1 3.5L3.2 5.7L8 1"
              stroke="#C9A227"
              strokeWidth="1.6"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="checkbox-tick checked"
            />
          </svg>
        )}
      </button>

      <button
        onClick={onOpen}
        className="min-w-0 flex-1 truncate text-left text-sm text-ink-100"
      >
        <span className={cn(task.completed && "text-ink-700 line-through")}>
          {task.title}
        </span>
      </button>

      <div className="hidden shrink-0 items-center gap-4 sm:flex">
        <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wide text-ink-500">
          <PriorityDot priority={task.priority} />
          {task.priority}
        </span>

        {projectName && (
          <span className="font-mono text-[10px] uppercase tracking-wide text-ink-700">
            {projectName}
          </span>
        )}

        {task.tags.length > 0 && (
          <span className="hidden max-w-[8rem] truncate text-[11px] text-ink-700 lg:inline">
            {task.tags.map((t) => `#${t}`).join(" ")}
          </span>
        )}

        {dueLabel && (
          <span
            className={cn(
              "font-mono text-[10px] uppercase tracking-wide",
              overdue ? "text-priority-urgent" : "text-ink-500"
            )}
          >
            {dueLabel}
            {task.dueTime ? ` · ${task.dueTime}` : ""}
          </span>
        )}
      </div>

      <div className="relative shrink-0">
        <button
          onClick={() => setMenuOpen((v) => !v)}
          onBlur={() => setTimeout(() => {
            setMenuOpen(false);
            setConfirming(false);
          }, 150)}
          className={cn(
            "rounded p-1 text-ink-700 transition-opacity hover:text-ink-100 group-hover:opacity-100",
            menuOpen ? "opacity-100" : "opacity-0"
          )}
          aria-label="Task actions"
        >
          <MoreHorizontal size={15} />
        </button>
        {menuOpen && (
          <div className="absolute right-0 top-7 z-10 w-40 overflow-hidden rounded-md border border-graphite-600 bg-graphite-800 shadow-xl">
            {!confirming ? (
              <>
                <button
                  onClick={onOpen}
                  className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-ink-300 hover:bg-graphite-700"
                >
                  <Pencil size={12} /> Edit
                </button>
                <button
                  onMouseDown={(e) => {
                    e.preventDefault();
                    setConfirming(true);
                  }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-priority-urgent hover:bg-graphite-700"
                >
                  <Trash2 size={12} /> Delete
                </button>
              </>
            ) : (
              <div className="px-3 py-2">
                <div className="mb-2 text-[11px] text-ink-300">
                  Delete this task?
                </div>
                <div className="flex gap-2">
                  <button
                    onMouseDown={(e) => {
                      e.preventDefault();
                      onDelete();
                    }}
                    className="rounded bg-priority-urgent/20 px-2 py-1 text-[11px] text-priority-urgent hover:bg-priority-urgent/30"
                  >
                    Delete
                  </button>
                  <button
                    onMouseDown={(e) => {
                      e.preventDefault();
                      setConfirming(false);
                      setMenuOpen(false);
                    }}
                    className="rounded px-2 py-1 text-[11px] text-ink-500 hover:text-ink-100"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
}
