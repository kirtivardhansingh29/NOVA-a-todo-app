import { Plus } from "lucide-react";

export function NewTaskButton({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1.5 rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-1.5 text-sm text-ink-100 transition-colors hover:border-signal-line hover:bg-signal-soft"
    >
      <Plus size={14} />
      New Task
    </button>
  );
}
