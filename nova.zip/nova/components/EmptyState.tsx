import { LucideIcon } from "lucide-react";

export function EmptyState({
  icon: Icon,
  title,
  subtitle,
}: {
  icon: LucideIcon;
  title: string;
  subtitle: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-24 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-full border border-graphite-600 text-ink-500">
        <Icon size={16} strokeWidth={1.5} />
      </div>
      <div className="font-mono text-micro uppercase tracking-wide text-ink-300">
        {title}
      </div>
      <div className="text-sm text-ink-700">{subtitle}</div>
    </div>
  );
}
