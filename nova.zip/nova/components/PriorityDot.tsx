import { Priority } from "@/types/task";
import { cn } from "@/lib/cn";

const colorMap: Record<Priority, string> = {
  low: "bg-priority-low",
  medium: "bg-priority-medium",
  high: "bg-priority-high",
  urgent: "bg-priority-urgent",
};

export function PriorityDot({ priority }: { priority: Priority }) {
  return (
    <span
      className={cn(
        "inline-block h-1.5 w-1.5 shrink-0 rounded-full",
        colorMap[priority]
      )}
      aria-hidden
    />
  );
}

export function PriorityLabel({ priority }: { priority: Priority }) {
  return (
    <span className="flex items-center gap-1.5 font-mono text-[10px] uppercase tracking-wide text-ink-500">
      <PriorityDot priority={priority} />
      {priority}
    </span>
  );
}
