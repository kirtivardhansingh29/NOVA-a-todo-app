"use client";

import { Priority } from "@/types/task";
import { useTasks } from "@/hooks/useTasks";
import { cn } from "@/lib/cn";

export type TaskFormValues = {
  title: string;
  description: string;
  priority: Priority;
  project: string; // "" = inbox
  dueDate: string;
  dueTime: string;
  tagsInput: string; // comma-separated raw input
};

const priorities: Priority[] = ["low", "medium", "high", "urgent"];

export function TaskForm({
  values,
  onChange,
}: {
  values: TaskFormValues;
  onChange: (patch: Partial<TaskFormValues>) => void;
}) {
  const { projects } = useTasks();

  return (
    <div className="flex flex-col gap-5">
      <div>
        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
          Title
        </label>
        <input
          autoFocus
          value={values.title}
          onChange={(e) => onChange({ title: e.target.value })}
          placeholder="What needs to get done?"
          className="w-full rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 placeholder:text-ink-700 focus:border-signal focus:outline-none"
        />
      </div>

      <div>
        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
          Description
        </label>
        <textarea
          value={values.description}
          onChange={(e) => onChange({ description: e.target.value })}
          placeholder="Optional detail…"
          rows={3}
          className="w-full resize-none rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 placeholder:text-ink-700 focus:border-signal focus:outline-none"
        />
      </div>

      <div>
        <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
          Priority
        </label>
        <div className="flex gap-1.5">
          {priorities.map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => onChange({ priority: p })}
              className={cn(
                "flex-1 rounded-md border px-2 py-1.5 font-mono text-[10px] uppercase tracking-wide transition-colors",
                values.priority === p
                  ? "border-signal-line bg-signal-soft text-ink-100"
                  : "border-graphite-600 text-ink-500 hover:border-graphite-500"
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
            Project
          </label>
          <select
            value={values.project}
            onChange={(e) => onChange({ project: e.target.value })}
            className="w-full rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 focus:border-signal focus:outline-none"
          >
            <option value="" className="bg-graphite-800">
              Inbox
            </option>
            {projects.map((p) => (
              <option key={p.id} value={p.id} className="bg-graphite-800">
                {p.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
            Tags
          </label>
          <input
            value={values.tagsInput}
            onChange={(e) => onChange({ tagsInput: e.target.value })}
            placeholder="urgent, review"
            className="w-full rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 placeholder:text-ink-700 focus:border-signal focus:outline-none"
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
            Due date
          </label>
          <input
            type="date"
            value={values.dueDate}
            onChange={(e) => onChange({ dueDate: e.target.value })}
            className="w-full rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 focus:border-signal focus:outline-none [color-scheme:dark]"
          />
        </div>
        <div>
          <label className="mb-1.5 block font-mono text-[10px] uppercase tracking-wide text-ink-700">
            Time
          </label>
          <input
            type="time"
            value={values.dueTime}
            onChange={(e) => onChange({ dueTime: e.target.value })}
            className="w-full rounded-md border border-graphite-600 bg-graphite-800/60 px-3 py-2 text-sm text-ink-100 focus:border-signal focus:outline-none [color-scheme:dark]"
          />
        </div>
      </div>
    </div>
  );
}

export function parseTags(input: string): string[] {
  return input
    .split(",")
    .map((t) => t.trim())
    .filter(Boolean);
}
