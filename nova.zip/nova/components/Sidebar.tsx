"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  CalendarClock,
  CheckCircle2,
  Inbox,
  Settings,
  Sun,
  X,
} from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { isOverdue, isToday, todayISO } from "@/lib/tasks";
import { cn } from "@/lib/cn";

const primaryNav = [
  { href: "/today", label: "Today", icon: Sun },
  { href: "/inbox", label: "Inbox", icon: Inbox },
  { href: "/upcoming", label: "Upcoming", icon: CalendarClock },
  { href: "/completed", label: "Completed", icon: CheckCircle2 },
];

export function Sidebar({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  const { tasks, projects } = useTasks();

  const counts = {
    today: tasks.filter((t) => !t.completed && (isToday(t) || isOverdue(t))).length,
    inbox: tasks.filter((t) => !t.completed && !t.project).length,
  };

  return (
    <div className="flex h-full flex-col bg-graphite-900">
      <div className="flex items-center justify-between border-b border-graphite-600 px-5 py-5">
        <div>
          <div className="font-display text-lg font-medium tracking-tight text-ink-100">
            NØVA
          </div>
          <div className="mt-0.5 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-700">
            Personal Task Operations
          </div>
        </div>
        <button
          onClick={onNavigate}
          className="rounded p-1 text-ink-500 hover:text-ink-100 md:hidden"
          aria-label="Close navigation"
        >
          <X size={16} />
        </button>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-4">
        <div className="flex flex-col gap-0.5">
          {primaryNav.map((item) => {
            const active = pathname === item.href;
            const count =
              item.href === "/today"
                ? counts.today
                : item.href === "/inbox"
                ? counts.inbox
                : undefined;
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onNavigate}
                className={cn(
                  "group flex items-center justify-between rounded-md px-2.5 py-1.5 text-sm transition-colors",
                  active
                    ? "bg-graphite-800 text-ink-100"
                    : "text-ink-500 hover:bg-graphite-800/60 hover:text-ink-100"
                )}
              >
                <span className="flex items-center gap-2.5">
                  <item.icon
                    size={15}
                    strokeWidth={1.75}
                    className={active ? "text-signal" : "text-ink-700"}
                  />
                  {item.label}
                </span>
                {typeof count === "number" && count > 0 && (
                  <span className="font-mono text-[11px] text-ink-700">
                    {count}
                  </span>
                )}
              </Link>
            );
          })}
        </div>

        <div className="mt-6">
          <div className="px-2.5 font-mono text-[10px] uppercase tracking-[0.14em] text-ink-700">
            Projects
          </div>
          <div className="mt-2 flex flex-col gap-0.5">
            {projects.map((p) => {
              const href = `/projects/${p.slug}`;
              const active = pathname === href;
              const count = tasks.filter(
                (t) => !t.completed && t.project === p.id
              ).length;
              return (
                <Link
                  key={p.id}
                  href={href}
                  onClick={onNavigate}
                  className={cn(
                    "group flex items-center justify-between rounded-md px-2.5 py-1.5 text-sm transition-colors",
                    active
                      ? "bg-graphite-800 text-ink-100"
                      : "text-ink-500 hover:bg-graphite-800/60 hover:text-ink-100"
                  )}
                >
                  <span className="flex items-center gap-2.5">
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full border",
                        active
                          ? "border-signal bg-signal"
                          : "border-ink-700 bg-transparent"
                      )}
                    />
                    {p.name}
                  </span>
                  {count > 0 && (
                    <span className="font-mono text-[11px] text-ink-700">
                      {count}
                    </span>
                  )}
                </Link>
              );
            })}
          </div>
        </div>
      </nav>

      <div className="border-t border-graphite-600 px-3 py-3">
        <Link
          href="/settings"
          onClick={onNavigate}
          className={cn(
            "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors",
            pathname === "/settings"
              ? "bg-graphite-800 text-ink-100"
              : "text-ink-500 hover:bg-graphite-800/60 hover:text-ink-100"
          )}
        >
          <Settings size={15} strokeWidth={1.75} className="text-ink-700" />
          Settings
        </Link>
        <div className="mt-2 flex items-center gap-2.5 px-2.5 py-1.5">
          <div className="flex h-6 w-6 items-center justify-center rounded-full border border-graphite-500 font-mono text-[10px] text-ink-300">
            KV
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-xs text-ink-300">Local session</span>
            <span className="font-mono text-[10px] text-ink-700">
              {todayISO()}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
