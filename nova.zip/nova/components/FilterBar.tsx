"use client";

import { FilterKind, SortKind } from "@/types/task";
import { cn } from "@/lib/cn";

const filters: { key: FilterKind; label: string }[] = [
  { key: "all", label: "All" },
  { key: "active", label: "Active" },
  { key: "completed", label: "Completed" },
  { key: "high", label: "High Priority" },
  { key: "today", label: "Today" },
  { key: "overdue", label: "Overdue" },
];

const sorts: { key: SortKind; label: string }[] = [
  { key: "dueDate", label: "Due Date" },
  { key: "priority", label: "Priority" },
  { key: "newest", label: "Newest" },
  { key: "oldest", label: "Oldest" },
];

export function FilterBar({
  filter,
  sort,
  onFilterChange,
  onSortChange,
}: {
  filter: FilterKind;
  sort: SortKind;
  onFilterChange: (f: FilterKind) => void;
  onSortChange: (s: SortKind) => void;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 border-b border-graphite-600 pb-3">
      <div className="flex flex-wrap gap-1.5">
        {filters.map((f) => (
          <button
            key={f.key}
            onClick={() => onFilterChange(f.key)}
            className={cn(
              "rounded-full border px-2.5 py-1 text-xs transition-colors",
              filter === f.key
                ? "border-signal-line bg-signal-soft text-ink-100"
                : "border-graphite-600 text-ink-500 hover:border-graphite-500 hover:text-ink-300"
            )}
          >
            {f.label}
          </button>
        ))}
      </div>

      <select
        value={sort}
        onChange={(e) => onSortChange(e.target.value as SortKind)}
        className="rounded-md border border-graphite-600 bg-transparent px-2 py-1 font-mono text-[11px] uppercase tracking-wide text-ink-500 hover:border-graphite-500 focus:outline-none"
      >
        {sorts.map((s) => (
          <option key={s.key} value={s.key} className="bg-graphite-800">
            {s.label}
          </option>
        ))}
      </select>
    </div>
  );
}
