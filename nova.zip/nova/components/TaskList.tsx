"use client";

import { useRef, useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Task } from "@/types/task";
import { TaskRow } from "@/components/TaskRow";
import { useTasks } from "@/hooks/useTasks";

export function TaskList({
  tasks,
  onOpen,
  reorderable = false,
}: {
  tasks: Task[];
  onOpen: (task: Task) => void;
  reorderable?: boolean;
}) {
  const { projects, toggleComplete, deleteTask, reorderTasks } = useTasks();
  const dragId = useRef<string | null>(null);
  const [overId, setOverId] = useState<string | null>(null);

  function projectName(id?: string) {
    return projects.find((p) => p.id === id)?.name;
  }

  function handleDrop(targetId: string) {
    if (!dragId.current || dragId.current === targetId) {
      dragId.current = null;
      setOverId(null);
      return;
    }
    const ids = tasks.map((t) => t.id);
    const from = ids.indexOf(dragId.current);
    const to = ids.indexOf(targetId);
    const next = [...ids];
    const [moved] = next.splice(from, 1);
    next.splice(to, 0, moved);
    reorderTasks(next);
    dragId.current = null;
    setOverId(null);
  }

  return (
    <div className="flex flex-col">
      <AnimatePresence initial={false}>
        {tasks.map((task) => (
          <div
            key={task.id}
            className={
              reorderable && overId === task.id
                ? "border-t-2 border-signal"
                : ""
            }
          >
            <TaskRow
              task={task}
              projectName={projectName(task.project)}
              onToggle={() => toggleComplete(task.id)}
              onOpen={() => onOpen(task)}
              onDelete={() => deleteTask(task.id)}
              draggable={reorderable}
              onDragStart={() => (dragId.current = task.id)}
              onDragOver={(e) => {
                e.preventDefault();
                setOverId(task.id);
              }}
              onDrop={() => handleDrop(task.id)}
            />
          </div>
        ))}
      </AnimatePresence>
    </div>
  );
}
