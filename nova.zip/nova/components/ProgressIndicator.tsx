"use client";

import { motion } from "framer-motion";

export function ProgressIndicator({
  completed,
  total,
}: {
  completed: number;
  total: number;
}) {
  const pct = total === 0 ? 0 : Math.round((completed / total) * 100);
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-baseline justify-between">
        <span className="font-mono text-micro uppercase tracking-wide text-ink-500">
          {completed} / {total} TASKS COMPLETE
        </span>
        <span className="font-mono text-micro text-ink-700">{pct}%</span>
      </div>
      <div className="h-[3px] w-full rounded-full bg-graphite-600">
        <motion.div
          className="h-full rounded-full bg-signal"
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.4, ease: "easeOut" }}
        />
      </div>
    </div>
  );
}
