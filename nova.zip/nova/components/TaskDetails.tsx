"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Trash2, X } from "lucide-react";
import { Task } from "@/types/task";
import { useTasks } from "@/hooks/useTasks";
import { TaskForm, TaskFormValues, parseTags } from "@/components/TaskForm";

function toValues(task: Task): TaskFormValues {
  return {
    title: task.title,
    description: task.description ?? "",
    priority: task.priority,
    project: task.project ?? "",
    dueDate: task.dueDate ?? "",
    dueTime: task.dueTime ?? "",
    tagsInput: task.tags.join(", "),
  };
}

export function TaskDetails({
  task,
  onClose,
}: {
  task: Task | null;
  onClose: () => void;
}) {
  const { updateTask, deleteTask, toggleComplete } = useTasks();
  const [values, setValues] = useState<TaskFormValues | null>(
    task ? toValues(task) : null
  );
  const [confirmingDelete, setConfirmingDelete] = useState(false);

  useEffect(() => {
    if (task) {
      setValues(toValues(task));
      setConfirmingDelete(false);
    }
  }, [task]);

  if (!task || !values) return null;

  function commit(patch: Partial<TaskFormValues>) {
    const next = { ...values!, ...patch };
    setValues(next);
    updateTask(task!.id, {
      title: next.title,
      description: next.description,
      priority: next.priority,
      project: next.project || undefined,
      tags: parseTags(next.tagsInput),
      dueDate: next.dueDate || undefined,
      dueTime: next.dueTime || undefined,
    });
  }

  return (
    <AnimatePresence>
      {task && (
        <motion.div
          className="fixed inset-0 z-50 flex justify-end bg-graphite-950/70 backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onClick={onClose}
        >
          <motion.div
            onClick={(e) => e.stopPropagation()}
            initial={{ x: 40, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: 40, opacity: 0 }}
            transition={{ duration: 0.2, ease: "easeOut" }}
            className="h-full w-full max-w-md overflow-y-auto border-l border-graphite-600 bg-graphite-900 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-graphite-600 px-5 py-4">
              <span className="font-mono text-[11px] uppercase tracking-wide text-ink-500">
                Task Details
              </span>
              <button
                onClick={onClose}
                className="text-ink-700 hover:text-ink-100"
                aria-label="Close"
              >
                <X size={16} />
              </button>
            </div>

            <div className="px-5 py-5">
              <TaskForm values={values} onChange={commit} />
            </div>

            <div className="flex items-center justify-between border-t border-graphite-600 px-5 py-3.5">
              <button
                onClick={() => toggleComplete(task.id)}
                className="rounded-md border border-graphite-600 px-3 py-1.5 text-sm text-ink-300 hover:border-graphite-500"
              >
                {task.completed ? "Restore task" : "Mark complete"}
              </button>

              {!confirmingDelete ? (
                <button
                  onClick={() => setConfirmingDelete(true)}
                  className="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm text-priority-urgent hover:bg-priority-urgent/10"
                >
                  <Trash2 size={13} /> Delete
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-xs text-ink-500">Delete task?</span>
                  <button
                    onClick={() => {
                      deleteTask(task.id);
                      onClose();
                    }}
                    className="rounded bg-priority-urgent/20 px-2 py-1 text-xs text-priority-urgent hover:bg-priority-urgent/30"
                  >
                    Confirm
                  </button>
                  <button
                    onClick={() => setConfirmingDelete(false)}
                    className="text-xs text-ink-500 hover:text-ink-100"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
