"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { useRouter } from "next/navigation";
import { CornerDownLeft, Search } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { matchesQuery } from "@/lib/tasks";
import { PriorityDot } from "@/components/PriorityDot";

export function CommandPalette({
  open,
  onClose,
}: {
  open: boolean;
  onClose: () => void;
}) {
  const { tasks, projects, setQuery: setGlobalQuery } = useTasks();
  const [query, setQuery] = useState("");
  const [activeIndex, setActiveIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  useEffect(() => {
    if (open) {
      setQuery("");
      setActiveIndex(0);
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }, [open]);

  const results = useMemo(() => {
    if (!query.trim()) return tasks.filter((t) => !t.completed).slice(0, 8);
    return tasks.filter((t) => matchesQuery(t, query)).slice(0, 8);
  }, [tasks, query]);

  function projectName(id?: string) {
    return projects.find((p) => p.id === id)?.name ?? "Inbox";
  }

  function selectResult(index: number) {
    const task = results[index];
    if (!task) return;
    setGlobalQuery(task.title);
    router.push(task.project ? `/projects/${task.project}` : "/inbox");
    onClose();
  }

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (!open) return;
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIndex((i) => Math.min(i + 1, results.length - 1));
      }
      if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIndex((i) => Math.max(i - 1, 0));
      }
      if (e.key === "Enter") {
        e.preventDefault();
        selectResult(activeIndex);
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, results, activeIndex]);

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-start justify-center bg-graphite-950/70 pt-[12vh] backdrop-blur-sm"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onClick={onClose}
        >
          <motion.div
            className="w-full max-w-lg overflow-hidden rounded-lg border border-graphite-600 bg-graphite-900 shadow-2xl"
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2.5 border-b border-graphite-600 px-4 py-3">
              <Search size={15} className="text-ink-700" />
              <input
                ref={inputRef}
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setActiveIndex(0);
                }}
                placeholder="Search tasks, projects, tags…"
                className="w-full bg-transparent text-sm text-ink-100 placeholder:text-ink-700 focus:outline-none"
              />
              <kbd className="rounded border border-graphite-600 px-1.5 py-0.5 font-mono text-[10px] text-ink-700">
                ESC
              </kbd>
            </div>

            <div className="max-h-80 overflow-y-auto py-1.5">
              {results.length === 0 && (
                <div className="px-4 py-6 text-center text-sm text-ink-700">
                  No matches.
                </div>
              )}
              {results.map((task, i) => (
                <button
                  key={task.id}
                  onClick={() => selectResult(i)}
                  onMouseEnter={() => setActiveIndex(i)}
                  className={`flex w-full items-center justify-between gap-3 px-4 py-2 text-left text-sm transition-colors ${
                    i === activeIndex
                      ? "bg-graphite-800 text-ink-100"
                      : "text-ink-300"
                  }`}
                >
                  <span className="flex min-w-0 items-center gap-2.5">
                    <PriorityDot priority={task.priority} />
                    <span className="truncate">{task.title}</span>
                  </span>
                  <span className="flex shrink-0 items-center gap-2 font-mono text-[10px] uppercase text-ink-700">
                    {projectName(task.project)}
                    {i === activeIndex && <CornerDownLeft size={11} />}
                  </span>
                </button>
              ))}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
