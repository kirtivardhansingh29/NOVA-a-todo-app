"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import { useTasks } from "@/hooks/useTasks";
import { TaskForm, TaskFormValues, parseTags } from "@/components/TaskForm";

const emptyValues = (defaultProject?: string): TaskFormValues => ({
  title: "",
  description: "",
  priority: "medium",
  project: defaultProject ?? "",
  dueDate: "",
  dueTime: "",
  tagsInput: "",
});

export function TaskComposer({
  open,
  onClose,
  defaultProject,
}: {
  open: boolean;
  onClose: () => void;
  defaultProject?: string;
}) {
  const { addTask } = useTasks();
  const [values, setValues] = useState<TaskFormValues>(
    emptyValues(defaultProject)
  );

  function handleClose() {
    setValues(emptyValues(defaultProject));
    onClose();
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!values.title.trim()) return;
    addTask({
      title: values.title.trim(),
      description: values.description.trim(),
      priority: values.priority,
      project: values.project || undefined,
      tags: parseTags(values.tagsInput),
      dueDate: values.dueDate || undefined,
      dueTime: values.dueTime || undefined,
    });
    handleClose();
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-50 flex items-start justify-center bg-graphite-950/70 pt-[8vh] backdrop-blur-sm sm:pt-[10vh]"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.15 }}
          onClick={handleClose}
        >
          <motion.form
            onSubmit={handleSubmit}
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, y: -8, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -8, scale: 0.98 }}
            transition={{ duration: 0.18, ease: "easeOut" }}
            className="max-h-[80vh] w-full max-w-md overflow-y-auto rounded-lg border border-graphite-600 bg-graphite-900 shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-graphite-600 px-5 py-4">
              <span className="font-mono text-[11px] uppercase tracking-wide text-ink-500">
                New Task
              </span>
              <button
                type="button"
                onClick={handleClose}
                className="text-ink-700 hover:text-ink-100"
                aria-label="Close"
              >
                <X size={16} />
              </button>
            </div>

            <div className="px-5 py-5">
              <TaskForm
                values={values}
                onChange={(patch) => setValues((v) => ({ ...v, ...patch }))}
              />
            </div>

            <div className="flex items-center justify-end gap-2 border-t border-graphite-600 px-5 py-3.5">
              <button
                type="button"
                onClick={handleClose}
                className="rounded-md px-3 py-1.5 text-sm text-ink-500 hover:text-ink-100"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!values.title.trim()}
                className="rounded-md bg-signal px-3.5 py-1.5 text-sm font-medium text-graphite-950 transition-opacity hover:opacity-90 disabled:opacity-40"
              >
                Create task
              </button>
            </div>
          </motion.form>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
