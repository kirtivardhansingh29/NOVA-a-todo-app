import { FilterKind, Priority, SortKind, Task } from "@/types/task";

export function genId(): string {
  return `t-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

export function todayISO(): string {
  return new Date().toISOString().slice(0, 10);
}

export function isOverdue(task: Task): boolean {
  if (!task.dueDate || task.completed) return false;
  return task.dueDate < todayISO();
}

export function isToday(task: Task): boolean {
  return task.dueDate === todayISO();
}

const priorityRank: Record<Priority, number> = {
  urgent: 0,
  high: 1,
  medium: 2,
  low: 3,
};

export function priorityWeight(p: Priority): number {
  return priorityRank[p];
}

export function matchesQuery(task: Task, query: string): boolean {
  if (!query.trim()) return true;
  const q = query.toLowerCase();
  return (
    task.title.toLowerCase().includes(q) ||
    (task.description ?? "").toLowerCase().includes(q) ||
    (task.project ?? "").toLowerCase().includes(q) ||
    task.tags.some((t) => t.toLowerCase().includes(q))
  );
}

export function applyFilter(tasks: Task[], filter: FilterKind): Task[] {
  switch (filter) {
    case "active":
      return tasks.filter((t) => !t.completed);
    case "completed":
      return tasks.filter((t) => t.completed);
    case "high":
      return tasks.filter(
        (t) => !t.completed && (t.priority === "high" || t.priority === "urgent")
      );
    case "today":
      return tasks.filter((t) => !t.completed && isToday(t));
    case "overdue":
      return tasks.filter((t) => isOverdue(t));
    case "all":
    default:
      return tasks;
  }
}

export function applySort(tasks: Task[], sort: SortKind): Task[] {
  const copy = [...tasks];
  switch (sort) {
    case "dueDate":
      return copy.sort((a, b) => {
        if (!a.dueDate && !b.dueDate) return a.order - b.order;
        if (!a.dueDate) return 1;
        if (!b.dueDate) return -1;
        return a.dueDate.localeCompare(b.dueDate);
      });
    case "priority":
      return copy.sort(
        (a, b) => priorityWeight(a.priority) - priorityWeight(b.priority)
      );
    case "newest":
      return copy.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    case "oldest":
      return copy.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
    default:
      return copy;
  }
}

export function groupUpcoming(tasks: Task[]) {
  const today = todayISO();
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowISO = tomorrow.toISOString().slice(0, 10);

  const weekEnd = new Date();
  weekEnd.setDate(weekEnd.getDate() + 7);
  const weekEndISO = weekEnd.toISOString().slice(0, 10);

  const groups: { label: string; tasks: Task[] }[] = [
    { label: "TODAY", tasks: [] },
    { label: "TOMORROW", tasks: [] },
    { label: "THIS WEEK", tasks: [] },
    { label: "LATER", tasks: [] },
  ];

  for (const t of tasks) {
    if (t.completed || !t.dueDate) continue;
    if (t.dueDate === today) groups[0].tasks.push(t);
    else if (t.dueDate === tomorrowISO) groups[1].tasks.push(t);
    else if (t.dueDate > tomorrowISO && t.dueDate <= weekEndISO)
      groups[2].tasks.push(t);
    else if (t.dueDate > weekEndISO) groups[3].tasks.push(t);
  }

  return groups.filter((g) => g.tasks.length > 0);
}

export function formatDueLabel(dueDate?: string): string {
  if (!dueDate) return "";
  const today = todayISO();
  const d = new Date(dueDate + "T00:00:00");
  const t = new Date(today + "T00:00:00");
  const diffDays = Math.round((d.getTime() - t.getTime()) / 86400000);

  if (diffDays === 0) return "TODAY";
  if (diffDays === 1) return "TOMORROW";
  if (diffDays === -1) return "YESTERDAY";
  if (diffDays < 0) return `${Math.abs(diffDays)}D OVERDUE`;
  if (diffDays < 7) {
    return d.toLocaleDateString("en-US", { weekday: "short" }).toUpperCase();
  }
  return d.toLocaleDateString("en-US", { month: "short", day: "numeric" }).toUpperCase();
}

export function formatFullDate(d: Date): string {
  const day = d.getDate();
  const month = d.toLocaleDateString("en-US", { month: "long" }).toUpperCase();
  const weekday = d.toLocaleDateString("en-US", { weekday: "long" }).toUpperCase();
  return `${day} ${month} / ${weekday}`;
}
