/**
 * Storage adapter
 * -----------------
 * All persistence for NOVA runs through this single module. Every read and
 * write in the app calls `storage.get` / `storage.set` rather than touching
 * `window.localStorage` directly. That means swapping localStorage for a
 * real backend later (a REST API, IndexedDB, Supabase, whatever) is a
 * one-file change: implement the same `StorageAdapter` interface and export
 * it here instead.
 */

export interface StorageAdapter {
  get<T>(key: string, fallback: T): T;
  set<T>(key: string, value: T): void;
  remove(key: string): void;
}

const isBrowser = typeof window !== "undefined";

class LocalStorageAdapter implements StorageAdapter {
  get<T>(key: string, fallback: T): T {
    if (!isBrowser) return fallback;
    try {
      const raw = window.localStorage.getItem(key);
      if (raw === null) return fallback;
      return JSON.parse(raw) as T;
    } catch {
      return fallback;
    }
  }

  set<T>(key: string, value: T): void {
    if (!isBrowser) return;
    try {
      window.localStorage.setItem(key, JSON.stringify(value));
    } catch {
      // Storage full or unavailable — fail silently, app still works in-memory
      // for the current session.
    }
  }

  remove(key: string): void {
    if (!isBrowser) return;
    try {
      window.localStorage.removeItem(key);
    } catch {
      // no-op
    }
  }
}

export const storage: StorageAdapter = new LocalStorageAdapter();

export const STORAGE_KEYS = {
  tasks: "nova:tasks",
  projects: "nova:projects",
  view: "nova:view",
  seeded: "nova:seeded",
} as const;
